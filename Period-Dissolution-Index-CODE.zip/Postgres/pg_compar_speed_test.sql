CREATE FUNCTION test_serch_numeric ()
RETURNS INTEGER
AS $$
DECLARE
i integer;
item RECORD;
begin
  FOR item IN (SELECT n FROM random_value)
  LOOP
    select count(*) into i from intervals where item.n between low and high;
  END LOOP;
return 1;
END; $$
LANGUAGE plpgsql;
