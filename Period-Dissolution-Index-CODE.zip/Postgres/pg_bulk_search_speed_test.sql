CREATE FUNCTION test_serch_bin ()
RETURNS INTEGER
AS $$
DECLARE
foo integer;
item RECORD;
begin
  FOR item IN (SELECT bin FROM random_value)
  LOOP
    select count(*) into foo from index_table  where item.bin like trim(base_interval);
  END LOOP;
return 1;
END; $$
LANGUAGE plpgsql;
