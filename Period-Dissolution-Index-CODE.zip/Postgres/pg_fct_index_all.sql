CREATE FUNCTION index_all ()
RETURNS INTEGER
AS $$
DECLARE
minu INTEGER;
BEGIN
SELECT min( interval_index(ID,bin_low,bin_high)) INTO minu
FROM intervals;
UPDATE index_table SET base_interval=trim(base_interval)||'%' where length(trim(base_interval))<34;
RETURN minu;
END; $$
LANGUAGE plpgsql;
