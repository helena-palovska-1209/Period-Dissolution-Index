CREATE FUNCTION interval_index (ID INTEGER, bin_low CHAR, bin_high CHAR)
	RETURNS INTEGER AS $$
DECLARE
	u INTEGER;
	low_token CHAR(1);
	high_token CHAR(1);
	i INTEGER;
BEGIN
	FOR i IN 1..34 LOOP
 		IF SUBSTR(bin_low,i,1)<SUBSTR(bin_high,i,1)THEN
			u:=i;
			EXIT;
		END IF;
	END LOOP;
	low_token:='1';
	high_token:='1';
	FOR i IN REVERSE 34..1 LOOP
 		IF i<u THEN
  			EXIT;
 		END IF;
  /*output step from low-end*/
 		IF low_token='1' THEN 	/*possible initial sequence of 0s preceded*/
  			IF substr(bin_low,i,1)='1' THEN	 /*initial sequence of 0s terminated*/
   				low_token:='0';
   				INSERT INTO index_table VALUES (ID,SUBSTR(bin_low,1,i));
  			END IF;
 		ELSIF SUBSTR(bin_low,i+1,1)='0' THEN
  			INSERT INTO index_table VALUES (ID,SUBSTR(bin_low,1,i)||'1');
 		END IF;
  /*output step from high-end*/
 		IF high_token='1' THEN 	/*possible initial sequence of 1s preceded*/
  			IF SUBSTR(bin_high,i,1)='0' THEN 	/*initial sequence of 1s terminated*/
   				high_token:='0';
  				INSERT INTO index_table VALUES (ID,SUBSTR(bin_high,1,i));
  			END IF;
 		ELSIF SUBSTR(bin_high,i+1,1)='1' THEN
  			INSERT INTO index_table VALUES (ID,SUBSTR(bin_high,1,i)||'0');
 		END IF;
	END LOOP;
 /*u-level processing*/
	IF low_token='1' THEN
 		INSERT INTO index_table VALUES (ID,SUBSTR(bin_low,1,u));
	END IF;
	IF high_token='1' THEN
 		INSERT INTO index_table VALUES (ID,SUBSTR(bin_high,1,u));
	END IF;
	RETURN u;
END; $$
LANGUAGE plpgsql;
