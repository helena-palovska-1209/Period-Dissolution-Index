CREATE TABLE random_value (n NUMBER, bin CHAR(67));	/*table for test data*/

create or replace PROCEDURE random_test_values  	/*fill table random_value with data*/
IS
 n NUMBER;
 bin CHAR;
BEGIN
 for i in 1..1000 loop 	                                        /*1000=desired number of rows*/
  select trunc(DBMS_RANDOM.value,20)*power(10,20) into n from dual; 	/*random 20-digit n*/
  insert into random_value values 
     (n,
     (SELECT LISTAGG(SIGN(BITAND(n, POWER(2,LEVEL-1))),'')
      WITHIN GROUP(ORDER BY LEVEL DESC) 
      FROM dual
      CONNECT BY level<=67));
 end loop;
END random_test_values;

/*for new test values use following*/
--DELETE FROM random_value;
--PURGE RECYCLEBIN;
--CALL random_test_values();
--COMMIT;
