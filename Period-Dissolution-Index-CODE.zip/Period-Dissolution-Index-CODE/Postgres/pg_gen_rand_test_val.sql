CREATE TABLE random_value (n bigint, bin char(34));	/*table for test data*/

INSERT INTO random_value	/*fill table random_value with data for n*/
 SELECT (random()*10^10)::bigint from generate_series(1,1000);

UPDATE random_value SET bin = n::BIT(34)::CHAR(34);	/*adding conversion of n to binary*/
