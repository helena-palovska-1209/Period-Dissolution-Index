INSERT INTO intervals SELECT	/*fill table intervals with data*/
	GENERATE_SERIES(1,100000),  /*100000=number of generated rows*/
	(RANDOM()*10^10)::BIGINT,
	null; 
UPDATE intervals SET high=low+(2*RANDOM()*10^9)::BIGINT;	/*average interval length = 1/10 whole domain*/
UPDATE intervals SET bin_low = low::BIT(34)::CHAR(34); 	    /*adding conversion of LOW to binary*/
UPDATE intervals SET bin_high = high::BIT(34)::CHAR(34);	/*adding conversion of HIGH to binary*/
