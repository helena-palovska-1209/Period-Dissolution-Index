CREATE TABLE intervals  (	/*table for intervals*/
	id INT PRIMARY KEY,
 	low BIGINT,     /*lower end of the interval*/
	high BIGINT,    /*upper end of the interval*/
	bin_low CHAR(34),   /*binary of low*/
 	bin_high CHAR(34)); /*binary of high*/
