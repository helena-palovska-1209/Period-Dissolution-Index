CREATE FUNCTION search_bin (IN bin VARCHAR(34))
RETURNS SETOF integer
AS $$
DECLARE
    item RECORD;
BEGIN
    FOR i IN 1..34 LOOP
      FOR item IN (select id from index_table where substr(bin,1,i) = base_interval)
      LOOP
        RETURN NEXT item.id;
      END LOOP;
   END LOOP; 
RETURN;                     
END;
$$ LANGUAGE plpgsql;
