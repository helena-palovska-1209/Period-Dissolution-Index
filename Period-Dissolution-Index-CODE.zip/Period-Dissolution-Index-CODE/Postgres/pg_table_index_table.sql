CREATE TABLE INDEX_TABLE (	/*table for the “interval index” */
	ID INTEGER,
	base_interval VARCHAR(34));