create or replace PROCEDURE test_serch_bin AS
i numeric;
foo numeric;
start_time pls_integer;
begin
  start_time := dbms_utility.get_time;
  FOR item IN (select bin from random_value)
  LOOP
    FOR i IN 1..67 LOOP
        select count(*) into foo  from index_table where substr(item.bin,1,i) = base_interval;
        dbms_output.put_line(foo);
    END LOOP;
  END LOOP;
  dbms_output.put_line((dbms_utility.get_time - start_time)/100 || ' seconds');
END;