CREATE OR REPLACE PROCEDURE index_all 	/* index whole table INTERVALS*/
IS
BEGIN
  FOR interval_record IN (SELECT id,bin_low,bin_high FROM intervals ORDER BY id)
  LOOP
    interval_index(interval_record.id,interval_record.bin_low ,interval_record.bin_high);
  END LOOP;
END index_all;
