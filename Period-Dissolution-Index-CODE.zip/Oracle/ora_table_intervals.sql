CREATE TABLE "INTERVALS" 
   (	"ID" NUMBER PRIMARY KEY, 
	"LOW" NUMBER (20,0),  --start point of an interval
	"HIGH" NUMBER (20,0), --end point of an interval 
	"BIN_LOW" CHAR(67 BYTE), --binary of LOW
	"BIN_HIGH" CHAR(67 BYTE) --binary of HIGH
   );