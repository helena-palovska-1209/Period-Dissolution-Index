CREATE OR REPLACE PROCEDURE interval_index (ID IN INTEGER, bin_low IN CHAR, bin_high IN CHAR)
IS
	low_token CHAR(1);
	high_token CHAR(1);
	u NUMBER;
	i NUMBER;
BEGIN
	FOR i IN 1..67 LOOP	/*67=length of both bin_low and bin_high*/
		IF substr(bin_low,i,1)<substr(bin_high,i,1) THEN
u:=i; 
EXIT;
		END IF;
	END LOOP;     	
	low_token:='1';
	high_token:='1';
	FOR i IN REVERSE 1..67
	LOOP
		 IF i<u THEN
 			EXIT;
		END IF;
		/*output step from low-end*/
		IF low_token='1' THEN 	/*possible initial sequence of 0s preceded*/
			IF substr(bin_low,i,1)='1' THEN	 /*initial sequence of 0s terminated*/
				low_token:='0';
				INSERT INTO index_table VALUES (ID,substr(bin_low,1,i));
			END IF;
		ELSIF substr(bin_low,i+1,1)='0' THEN
			INSERT INTO index_table VALUES (ID,substr(bin_low,1,i)||'1');
		END IF;
		/*output step from high-end*/
		IF high_token='1' THEN 	/*possible initial sequence of 1s preceded*/
			IF substr(bin_high,i,1)='0' THEN 	/*initial sequence of 1s terminated*/
				high_token:='0';
				INSERT INTO index_table VALUES (ID,substr(bin_high,1,i));
			END IF;
		ELSIF substr(bin_high,i+1,1)='1' THEN
			INSERT INTO index_table VALUES (ID,substr(bin_high,1,i)||'0');
		END IF;
	END LOOP;
	/*u-level:*/
	IF low_token='1' THEN
		INSERT INTO index_table VALUES (ID,substr(bin_low,1,u));
	END IF;
	IF high_token='1' THEN
		INSERT INTO index_table VALUES (ID,substr(bin_high,1,u));
	END IF;
END interval_index;