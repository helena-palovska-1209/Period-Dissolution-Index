INSERT INTO intervals 	/*fill table intervals with data*/
	SELECT LEVEL,
	trunc(DBMS_RANDOM.value,20)*power(10,20),           /*20 digit number*/
	null,null, null    	
 	FROM dual
 CONNECT BY LEVEL<=1000;        	/*1000=desired number of rows*/

UPDATE intervals SET high=low
	+2*trunc(DBMS_RANDOM.value,19)*power(10,19);	/*average interval length = 1/10 whole domain*/

UPDATE intervals SET bin_low = (
SELECT LISTAGG(SIGN(BITAND(low, POWER(2,LEVEL-1))),'') 
WITHIN GROUP(ORDER BY LEVEL DESC) 
FROM dual
CONNECT BY LEVEL<=67); 	/*adding conversion of LOW to binary zdroj*/

UPDATE intervals SET bin_high = (
SELECT LISTAGG(SIGN(BITAND(high, POWER(2,LEVEL-1))),'') 
WITHIN GROUP(ORDER BY LEVEL DESC) 
FROM dual
CONNECT BY LEVEL<=67); 	/*adding conversion of HIGH to binary*/


