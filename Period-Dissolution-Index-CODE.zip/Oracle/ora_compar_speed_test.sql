create or replace PROCEDURE test_serch_numeric AS
i numeric;
start_time pls_integer;
begin
  start_time := dbms_utility.get_time;
  FOR item IN (select n from random_value)
  LOOP
    select count(*) into i from intervals where item.n between low and high;
  END LOOP;
  dbms_output.put_line((dbms_utility.get_time - start_time)/100 || ' seconds');
END test_serch_numeric;