create type outID as table of number;

create or replace FUNCTION serch_bin (bin IN CHAR) RETURN outID PIPELINED IS
i numeric;
j numeric;
AUXILIARY outID := outID();
begin
    FOR i IN 1..67 LOOP
        select id BULK COLLECT INTO AUXILIARY from index_table where substr(bin,1,i) = base_interval;
        for j in 1..AUXILIARY.COUNT LOOP
         PIPE ROW (AUXILIARY(j));
        END LOOP;
    END LOOP;
END serch_bin;
